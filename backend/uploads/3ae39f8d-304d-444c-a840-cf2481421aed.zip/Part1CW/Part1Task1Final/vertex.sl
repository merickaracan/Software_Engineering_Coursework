attribute vec3 aVertexPosition; // 3D position of this vertex
    attribute vec4 aVertexNormal; // normal vector of this vertex
    
    uniform mat4 uMVMatrix;
    uniform mat4 uPMatrix;
    
    uniform mat4 uMMatrix;
    
    varying vec4 vColor;
    
    void main(void) {
        vec3 Ia = vec3(1.0);              // ambient light intensity
        vec3 Ii = vec3(1.0);              // directional light intensity (white)
        
        vec3 ka = vec3(0.0, 0.1, 0.0);    // ambient coefficients (green material)
        vec3 kd = vec3(0.0, 0.4, 0.0);    // diffuse coefficients
        vec3 ks = vec3(0.5, 0.5, 0.5);    // specular coefficients
        vec3 light = normalize(vec3(0.5, 0.5, 1.0)); // direction towards light
        float se  = 25.0;                 // specular power constant
    

        // Camera position in world space from my view 
        vec3 C = vec3(0.0, 1.5, 7.0);
    
        // transform position (P)/normal (N) into world space for lighting 
        vec3 position = (uMMatrix * vec4(aVertexPosition, 1.0)).xyz; // w = point
        vec3 normal = normalize((uMMatrix * vec4(aVertexNormal.xyz, 0.0)).xyz); // w = direction
    
        // View direction (V) and reflection (R)
        vec3 view = normalize(C - position);
        vec3 incident = -light; // flip direction of light
        vec3 reflection = reflect(incident, normal);
    
        // Diffuse and specular terms 
        float diff = max(dot(normal, light), 0.0); // green brightness
        float spec = 0.0; // white highlight
        if (diff > 0.0) {
            spec = pow(max(dot(reflection, view), 0.0), se);
        }
    
        // Complete equation 
        vec3 rgb = Ia * ka + Ii * (kd * diff + ks * spec);
        vColor = vec4(rgb, 1.0);
    
        gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);
    }