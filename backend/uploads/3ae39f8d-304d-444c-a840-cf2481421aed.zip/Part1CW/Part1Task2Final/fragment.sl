precision mediump float;

varying vec3 vNormal;
varying vec3 vWorldPos;

void main(void) {
    
    vec3 ka = vec3(0.0, 0.1, 0.0); // ambient coefficients
    vec3 kd = vec3(0.0, 0.4, 0.0); // diffuse coefficients
    vec3 ks = vec3(0.5, 0.5, 0.5); // specular coefficients
    
    vec3 light = normalize(vec3(0.5, 0.5, 1.0)); // direction towards light
    float se = 25.0; // specular power constant

    vec3 normal = normalize(vNormal);
    vec3 campos = vec3(0.0, 1.5, 7.0); // reflection of light/ camera position
    vec3 view = normalize(campos -vWorldPos);

    // Ambient
    vec3 ambient = ka; // the green colour

    // Diffuse
    float diff = max(dot(normal, light), 0.0); // brightness based on light angle
    vec3 diffuse = kd * diff;

    // Specular
    vec3 reflection = reflect(-light, normal); 
    float spec = pow(max(dot(reflection, view), 0.0), se); //shiny highlight
    vec3 specular = ks * spec;

    gl_FragColor = vec4(ambient + diffuse + specular, 1.0);
}