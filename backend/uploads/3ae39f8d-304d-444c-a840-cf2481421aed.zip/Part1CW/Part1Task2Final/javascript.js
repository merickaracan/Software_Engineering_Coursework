        var canvas;
		var gl;
		var mMatrix = glMatrix.mat4.create();
		var vMatrix = glMatrix.mat4.create();
		var mvMatrix = glMatrix.mat4.create();
		var pMatrix = glMatrix.mat4.create();
		var shaderProgram;


		function init() {
			canvas = document.getElementById('glcanvas');

			try {
				gl = canvas.getContext("webgl");
			} catch (e) {
				alert("Could not initialize WebGL");
				return false;
			}

			window.addEventListener('resize', resize);
			resize();

			initShaders();
			createGeometry();

			gl.clearColor(0.1, 0.25, 0.25, 1.0);
			gl.enable(gl.DEPTH_TEST);
			return true;
		}


		function resize() {
			glMatrix.mat4.perspective(pMatrix, 45, 1.0, 0.1, 10000.0);
			canvas.width = 500;
			canvas.height = 500;
			gl.viewport(0, 0, 500, 500);
		}


		function getShaderFragment(gl, src) {

			var shader;
				shader = gl.createShader(gl.FRAGMENT_SHADER);

			gl.shaderSource(shader, src);
			gl.compileShader(shader);

			if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
				alert(gl.getShaderInfoLog(shader));
				return null;
			}

			return shader;
		}
		
		function getShaderVertex(gl, src) {

			var shader;
				shader = gl.createShader(gl.VERTEX_SHADER);

			gl.shaderSource(shader, src);
			gl.compileShader(shader);

			if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
				alert(gl.getShaderInfoLog(shader));
				return null;
			}

			return shader;
		}


		function initShaders() {
			var fragmentShader = getShaderFragment(gl, PlaygroundGetFragmentShader());
			var vertexShader = getShaderVertex(gl, PlaygroundGetVertexShader());

			shaderProgram = gl.createProgram();
			gl.attachShader(shaderProgram, vertexShader);
			gl.attachShader(shaderProgram, fragmentShader);
			gl.linkProgram(shaderProgram);

			if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
				alert("Could not initialise shaders");
			}

			gl.useProgram(shaderProgram);

			shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
			gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

			shaderProgram.vertexNormalAttribute = gl.getAttribLocation(shaderProgram, "aVertexNormal");
			gl.enableVertexAttribArray(shaderProgram.vertexNormalAttribute);

			shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
			shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
			shaderProgram.mMatrixUniform = gl.getUniformLocation(shaderProgram, "uMMatrix");
		}


        // calculate the normal given three vertices.
        function planeNormal(a, b, c) {
            // Compute vectors AB and AC
            const ab = {
                x: b.x - a.x,
                y: b.y - a.y,
                z: b.z - a.z
            };

            const ac = {
                x: c.x - a.x,
                y: c.y - a.y,
                z: c.z - a.z
            };

            // Cross product AB × AC
            const normal = {
                x: ab.y * ac.z - ab.z * ac.y,
                y: ab.z * ac.x - ab.x * ac.z,
                z: ab.x * ac.y - ab.y * ac.x
            };

            // Normalize the vector
            const length = Math.sqrt(
                normal.x * normal.x +
                normal.y * normal.y +
                normal.z * normal.z
            );

            if (length === 0) {
                throw new Error("Vertices are collinear; normal is undefined.");
            }

            return {
                x: normal.x / length,
                y: normal.y / length,
                z: normal.z / length
            };
        }



		var triangleVertexPositionBuffer;
		//var triangleVertexColorBuffer;
		function createGeometry() {
		    
		    var tvcount = utah_teapot.faces.length;
		    var tfcount = tvcount/3;
		    var vertices = new Array(tvcount*3);
		    
		    // build triangle vertex array from teapot data
		    for(i=0; i< tvcount;i+=1)
		    {
		        vertices[i*3 + 0] = utah_teapot.vertices[(utah_teapot.faces[i]-1)*3 + 0]; //x
		        vertices[i*3 + 1] = utah_teapot.vertices[(utah_teapot.faces[i]-1)*3 + 1]; //y
		        vertices[i*3 + 2] = utah_teapot.vertices[(utah_teapot.faces[i]-1)*3 + 2]; //z
		    }

			triangleVertexPositionBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexPositionBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
			triangleVertexPositionBuffer.itemSize = 3;
			triangleVertexPositionBuffer.numItems = utah_teapot.faces.length;

            // face normals for each triangle
            var faceNormals = new Array(tfcount);
            for(i=0; i< tfcount;i+=1)
            {
                faceNormals[i] = planeNormal(
                    {x:vertices[i*9+0], y:vertices[i*9+1], z:vertices[i*9+2]},
                    {x:vertices[i*9+3], y:vertices[i*9+4], z:vertices[i*9+5]},
                    {x:vertices[i*9+6], y:vertices[i*9+7], z:vertices[i*9+8]}
                );
            }

            // accumulate face normals per original vertex index
            var vertexNormalAccum = {};
            for(i=0; i< tvcount; i+=1)
            {
                var origIdx = utah_teapot.faces[i] - 1;
                var faceIdx = Math.floor(i / 3);
                if (!vertexNormalAccum[origIdx]) {
                    vertexNormalAccum[origIdx] = {x:0, y:0, z:0};
                }
                vertexNormalAccum[origIdx].x += faceNormals[faceIdx].x;
                vertexNormalAccum[origIdx].y += faceNormals[faceIdx].y;
                vertexNormalAccum[origIdx].z += faceNormals[faceIdx].z;
            }

            // normalize the accumulated normals
            for (var key in vertexNormalAccum) {
                var n = vertexNormalAccum[key];
                var len = Math.sqrt(n.x*n.x + n.y*n.y + n.z*n.z);
                if (len > 0) { n.x /= len; n.y /= len; n.z /= len; }
            }

            // assign averaged normals to each vertex
            var normals = new Array(tvcount*4);
            for(i=0; i< tvcount; i+=1)
            {
                var origIdx = utah_teapot.faces[i] - 1;
                normals[i*4]   = vertexNormalAccum[origIdx].x;
                normals[i*4+1] = vertexNormalAccum[origIdx].y;
                normals[i*4+2] = vertexNormalAccum[origIdx].z;
                normals[i*4+3] = 1.0;
            }

			triangleVertexNormalBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexNormalBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);
			triangleVertexNormalBuffer.itemSize = 4;
			triangleVertexNormalBuffer.numItems = utah_teapot.faces.length;
		}
		function drawScene() {
			gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

			glMatrix.mat4.identity(vMatrix);
			glMatrix.mat4.translate(vMatrix, vMatrix, [0, -1.5, -7]);
			
			var time = performance.now() / 2000;
			glMatrix.mat4.identity(mMatrix);
			glMatrix.mat4.rotate(mMatrix, mMatrix, time / 2 * Math.PI, [0, 1, 0]);

			glMatrix.mat4.multiply(mvMatrix, vMatrix, mMatrix);

			gl.useProgram(shaderProgram);

			gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexPositionBuffer);
			gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, triangleVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);

			gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexNormalBuffer);
			gl.vertexAttribPointer(shaderProgram.vertexNormalAttribute, triangleVertexNormalBuffer.itemSize, gl.FLOAT, false, 0, 0);

			gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
			gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
			gl.uniformMatrix4fv(shaderProgram.mMatrixUniform, false, mMatrix);

			gl.drawArrays(gl.TRIANGLES, 0, triangleVertexPositionBuffer.numItems);
		}


		function update() {
			drawScene();

			requestAnimationFrame(update);
		}

		if (init()) {
			update();
		}