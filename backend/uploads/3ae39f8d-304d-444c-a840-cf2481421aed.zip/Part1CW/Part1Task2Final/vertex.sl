attribute vec3 aVertexPosition;
attribute vec4 aVertexNormal;

uniform mat4 uMVMatrix;
uniform mat4 uPMatrix;
uniform mat4 uMMatrix;

varying vec3 vNormal;
varying vec3 vWorldPos;

void main(void) {
    vec3 ka = vec3(0.0,0.1,0.0); // ambient coefficients
    vec3 kd = vec3(0.0,0.4,0.0); // diffuse coefficients
    vec3 ks = vec3(0.5,0.5,0.5); // specular coefficients
    vec3 light = normalize(vec3(0.5,0.5,1.0)); // direction towards light
    float se = 25.0; // specular power constant
    
    //gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);
    
    // for vertex shading, replace the next line with the lighting calculation
    // you will need the vertex position in world space, the normal
    // and the constants defined above. Assume the light is white.
    
    // for fragment shading, you will need to forward the normal and position
    // to the fragment shader, where the coefficients will also be needed.
    // and perform the lighting calculation there instead.
    vNormal = normalize((uMMatrix * vec4(aVertexNormal.xyz, 0.0)).xyz);
    vWorldPos = (uMMatrix * vec4(aVertexPosition, 1.0)).xyz;
    
    gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);
}